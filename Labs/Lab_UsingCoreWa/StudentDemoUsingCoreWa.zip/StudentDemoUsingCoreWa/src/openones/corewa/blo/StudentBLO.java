package openones.corewa.blo;

import java.util.List;

import openones.corewa.dao.ClassDAO;
import openones.corewa.dao.StudentDAO;
import openones.corewa.dto.SimpleClassDTO;
import openones.corewa.dto.SimpleStudentDTO;

import org.apache.log4j.Logger;

/**
 * Process business logic for SimpleLoginPortlet.
 * @author HaLT
 *
 */
public class StudentBLO {
	/**
	 * log property.
	 */
	private static Logger log = Logger.getLogger("AddStudentBLO");
	
	/**
	 * DAO property.
	 */
	private StudentDAO studentDAO = new StudentDAO();
	private ClassDAO classDAO = new ClassDAO();
	
	public boolean checkExistStudent(String id) {
		log.debug("checkExistStudent.start");

		boolean res = false;
		SimpleStudentDTO dto = (SimpleStudentDTO) studentDAO.getStudent(id);
		if (dto == null) {
			res = true;
		}

		log.debug("checkExistStudent.end");
		return res;
	}
	
	public boolean insertStudent (String id, String name, String birthday, String classId, float mark, String email, String avatar){
		return studentDAO.insertStudent(id, name, birthday, classId, mark, email, avatar);
	}
	
	public List<SimpleStudentDTO> getAllStudent(){
		return studentDAO.getAllStudent();
	}
	
	public List<SimpleClassDTO> getAllClass(){
		return classDAO.getAllClass();
	}
}

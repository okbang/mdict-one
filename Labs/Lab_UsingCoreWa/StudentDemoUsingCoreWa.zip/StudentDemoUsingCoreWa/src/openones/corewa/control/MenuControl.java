package openones.corewa.control;

import java.io.IOException;
import java.util.List;
import java.util.logging.Level;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import openones.corewa.BaseOutForm;
import openones.corewa.blo.StudentBLO;
import openones.corewa.dto.SimpleClassDTO;
import openones.corewa.dto.SimpleStudentDTO;

public class MenuControl extends BaseControl {
    
	@Override
	public BaseOutForm procInit(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		StudentBLO blo = new StudentBLO();
		BaseOutForm outForm = new BaseOutForm();
		if (req.getParameter("eventId").equals("Add")) {
			List<SimpleClassDTO> classes = blo.getAllClass();
			outForm = new BaseOutForm();
	        outForm.putRequest("classes", classes);
		} else if (req.getParameter("eventId").equals("List")) {
			 List<SimpleStudentDTO> listStudents = blo.getAllStudent();
		     outForm = new BaseOutForm();
		     outForm.putRequest("students", listStudents);
		} else {
			return super.procInit(req, resp);
		}
		return outForm;
	}
	
	public void procList(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LOG.log(Level.INFO, "procList.START");
        LOG.log(Level.INFO, "procList.END");
    }
    public void procAdd(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        LOG.log(Level.INFO, "procAdd.START");
        LOG.log(Level.INFO, "procAdd.END");
    }
}

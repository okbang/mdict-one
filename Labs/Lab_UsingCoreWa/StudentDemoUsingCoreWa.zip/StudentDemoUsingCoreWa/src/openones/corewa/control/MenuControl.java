package openones.corewa.control;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import openones.corewa.BaseOutForm;
import openones.corewa.dao.StudentDAO;
import openones.corewa.dto.SimpleStudentDTO;

public class MenuControl extends BaseControl {
    
	@Override
	public BaseOutForm procInit(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
		BaseOutForm outForm = new BaseOutForm();
		if (req.getParameter("eventId").equals("Add")) {
			outForm = new BaseOutForm();
		} else if (req.getParameter("eventId").equals("List")) {
			 List<SimpleStudentDTO> listStudents = StudentDAO.LIST_STUDENT;
		     outForm = new BaseOutForm();
		     outForm.putRequest("students", listStudents);
		} else {
			return super.procInit(req, resp);
		}
		return outForm;
	}
}

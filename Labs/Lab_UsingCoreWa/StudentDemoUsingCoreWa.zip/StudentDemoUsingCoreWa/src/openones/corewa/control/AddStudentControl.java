package openones.corewa.control;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import openones.corewa.BaseOutForm;
import openones.corewa.blo.StudentBLO;
import openones.corewa.dto.SimpleClassDTO;

/**
 * 
 * @author HaLT
 *
 */
public class AddStudentControl extends BaseControl {
    
    @Override
	public BaseOutForm procInit(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
    	if (req.getParameter("eventId") != null && req.getParameter("eventId").equals("Submit")) {
    		StudentBLO blo = new StudentBLO();
    		BaseOutForm outForm = new BaseOutForm();
    		List<SimpleClassDTO> classes = blo.getAllClass();
			outForm = new BaseOutForm();
	        outForm.putRequest("classes", classes);
    		
    		String studentId = req.getParameter("studentId");
    		String studentName = req.getParameter("studentName");
    		int day = Integer.parseInt(req.getParameter("day"));
    		int month = Integer.parseInt(req.getParameter("month"));
    		int year = Integer.parseInt(req.getParameter("year"));
    		String dayStr = day < 10 ? "0" + day : day + "";
    		String monthStr = month < 10 ? "0" + month : month + "";
    		String birthday = year + "-" + monthStr + "-" + dayStr;
    		String classId = req.getParameter("classId");
    		String markStr = req.getParameter("mark");
    		float mark = 0;
    		String email = req.getParameter("email");
    		String avatar = req.getParameter("avatar");
    		if (avatar == null)
    			avatar = "";
    		
    		String error = "";
    		if (studentId == null || studentId.equals(""))
    			error = "Please input Student Id";
    		else {
    			try {
    				mark = Float.parseFloat(markStr);
    			} catch (NumberFormatException e) {
    				error = "Mark must be a positive number";
    			}
    		}
    		
    		if (! error.equals("")){
    			outForm.putRequest("error", error);
    			return outForm;
    		} else {
    			if (blo.insertStudent(studentId, studentName, birthday, classId, mark, email, avatar))
    				outForm.putRequest("addResult", "Student has been added successfully !");
    			else
    				outForm.putRequest("error", "Student ID is already exist");
    			return outForm;
    		}
    	} else
    		return super.procInit(req, resp);
    	
	}
    
}

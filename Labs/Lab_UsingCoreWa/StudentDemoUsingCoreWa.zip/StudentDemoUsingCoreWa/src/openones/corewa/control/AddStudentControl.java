package openones.corewa.control;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import openones.corewa.BaseOutForm;
import openones.corewa.dao.StudentDAO;

public class AddStudentControl extends BaseControl {
    
    @Override
	public BaseOutForm procInit(HttpServletRequest req, HttpServletResponse resp)
			throws ServletException, IOException {
    	req.setCharacterEncoding("UTF-8");
    	if (req.getParameter("eventId") != null && req.getParameter("eventId").equals("Submit")) {
    		BaseOutForm outForm = new BaseOutForm();
			outForm = new BaseOutForm();
    		
    		String studentId = req.getParameter("studentId");
    		String studentName = req.getParameter("studentName");
    		int day = Integer.parseInt(req.getParameter("day"));
    		int month = Integer.parseInt(req.getParameter("month"));
    		int year = Integer.parseInt(req.getParameter("year"));
    		String birthday = year + "-" + month + "-" + day;
    		String markStr = req.getParameter("mark");
    		float mark = 0;
    		String email = req.getParameter("email");
    		String avatar = req.getParameter("avatar");
    		if (avatar == null)
    			avatar = "";
    		String error = "";
    		if (studentId == null || studentId.equals(""))
    			error = "Please input Student Id";
    		else {
    			try {
    				mark = Float.parseFloat(markStr);
    			} catch (NumberFormatException e) {
    				error = "Mark must be a positive number";
    			}
    		}
    		if (! error.equals("")){
    			outForm.putRequest("error", error);
    			return outForm;
    		} else {
    			if (StudentDAO.insertStudent(studentId, studentName, birthday, mark, email, avatar))
    				outForm.putRequest("addResult", "Student has been added successfully !");
    			else
    				outForm.putRequest("error", "Student ID is already exist");
    			return outForm;
    		}
    	} else
    		return super.procInit(req, resp);
	}
}

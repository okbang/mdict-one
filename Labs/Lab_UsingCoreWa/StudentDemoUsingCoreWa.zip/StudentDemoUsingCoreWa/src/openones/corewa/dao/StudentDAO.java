package openones.corewa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import openones.corewa.dto.SimpleClassDTO;
import openones.corewa.dto.SimpleStudentDTO;
import openones.corewa.util.Constants;

import org.apache.log4j.Logger;

/**
 * 
 * @author HaLT
 *
 */
public class StudentDAO {
	private static Logger log = Logger.getLogger("StudentDAO");
	
	public SimpleStudentDTO getStudent(String id) {
		SimpleStudentDTO dto = null;		
		Connection conn = null;
		String query = Constants.BLANK_VALUE;
		ResultSet rs = null;
		PreparedStatement pStat = null;

		try {
			// query command
			query = "select * from student where studentId=?";
			// get connection
			conn = openones.corewa.util.Connection.getConnection();
			// prepare statement
			pStat = conn.prepareStatement(query);
			pStat.setString(1, id);
			// execute query
			rs = pStat.executeQuery();
			// get result
			while (rs.next()) {
				dto = new SimpleStudentDTO();
				dto.setId(rs.getString("studentId"));
				dto.setName(rs.getString("studentName"));
				dto.setBirthday(rs.getDate("birthday"));
				dto.setAvatar(rs.getString("avatar"));
				String classId = rs.getString("classId");
				ClassDAO classDAO = new ClassDAO();
				SimpleClassDTO simpleClassDTO = classDAO.getClass(classId);
				dto.setsClass(simpleClassDTO);
				dto.setMark(rs.getFloat("mark"));
				dto.setEmail(rs.getString("email"));
			}
		} catch (Exception sqlEx) {
			log.error("SimpleLoginDAO.getUser " + sqlEx);
		} finally {
			try {
				rs.close();
				pStat.close();
				conn.close();
			} catch (SQLException sqlEx) {
				log.error("SimpleLoginDAO.getUser " + sqlEx);
			}
		}

		return dto;
	}
	
	public List<SimpleStudentDTO> getAllStudent(){
		List<SimpleStudentDTO> list = new ArrayList<SimpleStudentDTO>();
		SimpleStudentDTO dto = null;
		Connection conn = null;
		String query = Constants.BLANK_VALUE;
		ResultSet rs = null;
		Statement stat = null;

		try {
			// query command
			query = "select * from student";
			// get connection
			conn = openones.corewa.util.Connection.getConnection();
			stat = conn.createStatement();
			// execute query
			rs = stat.executeQuery(query);
			// get result
			while (rs.next()) {
				dto = new SimpleStudentDTO();
				dto.setId(rs.getString("studentId"));
				dto.setName(rs.getString("studentName"));
				dto.setBirthday(rs.getDate("birthday"));
				dto.setAvatar(rs.getString("avatar"));
				String classId = rs.getString("classId");
				ClassDAO classDAO = new ClassDAO();
				SimpleClassDTO simpleClassDTO = classDAO.getClass(classId);
				dto.setsClass(simpleClassDTO);
				dto.setMark(rs.getFloat("mark"));
				dto.setEmail(rs.getString("email"));
				list.add(dto);
			}
		} catch (Exception sqlEx) {
			log.error("ClassDAO.getAllClass " + sqlEx);
		} finally {
			try {
				rs.close();
				stat.close();
				conn.close();
			} catch (SQLException sqlEx) {
				log.error("ClassDAO.getAllClass " + sqlEx);
			}
		}
		return list;
	}
	
	public boolean insertStudent(String id, String name, String birthday, String classId, float mark, String email, String avatar){
		boolean result = false;
		Connection conn = null;
		String query = Constants.BLANK_VALUE;
		PreparedStatement pStat = null;
		
//		String day = birthday.substring(0, 2);
//		String month = birthday.substring(3, 5);
//		String year = birthday.substring(6, 10);
//		birthday = year + "-" + month + "-" + day;

		try {
			// query command
			query = "insert into student (studentId, studentName, birthday, classId, mark, email, avatar) values (?, ?, ?, ?, ?, ?, ?)";
			// get connection
			conn = openones.corewa.util.Connection.getConnection();
			// prepare statement
			pStat = conn.prepareStatement(query);
			pStat.setString(1, id);
			pStat.setString(2, name);
			pStat.setString(3, birthday);
			pStat.setString(4, classId);
			pStat.setFloat(5, mark);
			pStat.setString(6, email);
			pStat.setString(7, avatar);
			// execute query
			int i = pStat.executeUpdate();
			if (i > 0)
				result = true;;
		} catch (Exception sqlEx) {
			log.error("SimpleLoginDAO.insert " + sqlEx);
		} finally {
			try {
				pStat.close();
				conn.close();
			} catch (SQLException sqlEx) {
				log.error("SimpleLoginDAO.insert " + sqlEx);
			}
		}

		return result;
	}
	
}

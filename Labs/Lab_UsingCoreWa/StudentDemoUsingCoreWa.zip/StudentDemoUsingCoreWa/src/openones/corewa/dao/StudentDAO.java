package openones.corewa.dao;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.List;
import java.util.StringTokenizer;

import openones.corewa.dto.SimpleStudentDTO;

/**
 * 
 * @author HaLT
 *
 */
public class StudentDAO {
	public static List<SimpleStudentDTO> LIST_STUDENT = getAllStudent();
	
	public static List<SimpleStudentDTO> getAllStudent(){
		List<SimpleStudentDTO> list = new ArrayList<SimpleStudentDTO>();
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.set(1989, Calendar.SEPTEMBER, 8);
		SimpleStudentDTO student1 = new SimpleStudentDTO("07130028", "Lưu Thúy Hà", calendar.getTime(), "avatar.jpg", 9, "luuhait@gmail.com");
		SimpleStudentDTO student2 = new SimpleStudentDTO("07130029", "Nhjm", calendar.getTime(), "avatar.jpg", 9.5f, "lth_sunflower@yahoo.com");
		SimpleStudentDTO student3 = new SimpleStudentDTO("07130030", "HaLT", calendar.getTime(), "avatar.jpg", 8, "luuha@gmail.com");
		list.add(student1);
		list.add(student2);
		list.add(student3);
		return list;
	}
	
	public static boolean insertStudent(String id, String name, String birthday, float mark, String email, String avatar){
		int day = 1, month = 1, year = 1989;
		StringTokenizer tokenizer = new StringTokenizer(birthday, "-");
		year = Integer.parseInt(tokenizer.nextToken());
		month = Integer.parseInt(tokenizer.nextToken());
		day = Integer.parseInt(tokenizer.nextToken());
		GregorianCalendar calendar = new GregorianCalendar();
		calendar.set(year, month - 1, day);
		Date myBirth = calendar.getTime();
		
		SimpleStudentDTO student = new SimpleStudentDTO(id, name, myBirth, avatar, mark, email);
		LIST_STUDENT.add(student);
		return true;
	}
	
}

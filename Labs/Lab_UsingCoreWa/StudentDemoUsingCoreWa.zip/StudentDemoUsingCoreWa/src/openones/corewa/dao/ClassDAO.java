package openones.corewa.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import openones.corewa.dto.SimpleClassDTO;
import openones.corewa.util.Constants;

import org.apache.log4j.Logger;

/**
 * 
 * @author HaLT
 *
 */
public class ClassDAO {
	private static Logger log = Logger.getLogger("ClassDAO");
	
	public SimpleClassDTO getClass (String id) {
		SimpleClassDTO dto = null;		
		Connection conn = null;
		String query = Constants.BLANK_VALUE;
		ResultSet rs = null;
		PreparedStatement pStat = null;

		try {
			// query command
			query = "select * from class where classId=?";
			// get connection
			conn = openones.corewa.util.Connection.getConnection();
			// prepare statement
			pStat = conn.prepareStatement(query);
			pStat.setString(1, id);
			// execute query
			rs = pStat.executeQuery();
			// get result
			while (rs.next()) {
				dto = new SimpleClassDTO();
				dto.setId(rs.getString("classId"));
				dto.setName(rs.getString("className"));
			}
		} catch (Exception sqlEx) {
			log.error("ClassDAO.getClass " + sqlEx);
		} finally {
			try {
				rs.close();
				pStat.close();
				conn.close();
			} catch (SQLException sqlEx) {
				log.error("ClassDAO.getClass " + sqlEx);
			}
		}
		return dto;
	}
	
	public List<SimpleClassDTO> getAllClass(){
		List<SimpleClassDTO> list = new ArrayList<SimpleClassDTO>();
		SimpleClassDTO dto = null;
		Connection conn = null;
		String query = Constants.BLANK_VALUE;
		ResultSet rs = null;
		Statement stat = null;

		try {
			// query command
			query = "select * from class";
			// get connection
			conn = openones.corewa.util.Connection.getConnection();
			stat = conn.createStatement();
			// execute query
			rs = stat.executeQuery(query);
			// get result
			while (rs.next()) {
				dto = new SimpleClassDTO();
				dto.setId(rs.getString("classId"));
				dto.setName(rs.getString("className"));
				list.add(dto);
			}
		} catch (Exception sqlEx) {
			log.error("ClassDAO.getAllClass " + sqlEx);
		} finally {
			try {
				rs.close();
				stat.close();
				conn.close();
			} catch (SQLException sqlEx) {
				log.error("ClassDAO.getAllClass " + sqlEx);
			}
		}
		return list;
	}
}

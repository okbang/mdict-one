package openones.corewa.util;

import java.io.InputStream;
import java.sql.DriverManager;
import java.util.Properties;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

/**
 * This class uses to get database connection.
 * @author HaLT
 *
 */
public class Connection {	
	/**
	 * props property.
	 * Contain the content of db.properties file.
	 */
	private static Properties props = new Properties();
	
	/**
	 * log property.
	 */
	private static Logger log = Logger.getLogger("Connection");

	// load the content of db.properties file.
	static {
		try {
			InputStream is = Connection.class
					.getResourceAsStream("/db.properties");
			props.load(is);
		} catch (Exception ex) {
			// in case occur exception, log it.
			log.error("Load db.properties", ex);
		}
	}

//	public static java.sql.Connection getConnection() {		
//		// load the driver and establish a connection.
//		try {
//			String jdbcDriver = props.getProperty(Constants.JDBD_DRIVER);
//			String jdbcUrl = props.getProperty(Constants.JDBD_URL);
//			String jdbcUser = props.getProperty(Constants.JDBD_USER);
//			String jdbcPassword = props.getProperty(Constants.JDBD_PASS);
//
//			Class.forName(jdbcDriver);
//			return (java.sql.Connection) DriverManager.getConnection(jdbcUrl,
//					jdbcUser, jdbcPassword);
//		} catch (Exception ex) {
//			// in case occur exception, log it.
//			log.error("getConnection", ex);
//		}
//		return null;
//	}
	// second way: using ResourceBundle class: fast and easy.
	private static ResourceBundle dbResource = ResourceBundle.getBundle("db");

	public static java.sql.Connection getConnection() {		
		// load the driver and establish a connection.
		try {
			// using resource bundle to get jdbcDriver
			String jdbcDriver = dbResource.getString(Constants.JDBD_DRIVER);
			String jdbcUrl = dbResource.getString(Constants.JDBD_URL);
			
			// using properties object.			
			String jdbcUser = props.getProperty(Constants.JDBD_USER);
			String jdbcPassword = props.getProperty(Constants.JDBD_PASS);

			Class.forName(jdbcDriver);
			return (java.sql.Connection) DriverManager.getConnection(jdbcUrl,
					jdbcUser, jdbcPassword);
		} catch (Exception ex) {
			// in case occur exception, log it.
			log.error("getConnection", ex);
		}
		return null;
	}

}

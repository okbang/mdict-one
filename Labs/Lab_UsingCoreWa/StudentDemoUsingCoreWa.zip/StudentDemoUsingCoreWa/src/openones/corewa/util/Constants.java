package openones.corewa.util;

/**
 * Constants of project.
 * @author HaLT
 *
 */
public class Constants {
	public static String JDBD_DRIVER = "jdbcDriver";
	public static String JDBD_URL = "jdbcUrl";
	public static String JDBD_USER = "jdbcUser";
	public static String JDBD_PASS = "jdbcPassword";
	
	public static String BLANK_VALUE = "";
	
	public static String ADD_ACTION = "add";
	public static String LIST_ACTION = "list";
	public static String BACK_ACTION = "back";

	public static String ADD_VIEW_PATH = "/WEB-INF/jsp/AddStudentPortlet_view.jsp";
	public static String LIST_VIEW_PATH = "/WEB-INF/jsp/ListStudent.jsp";

	public static String ERR_MESS_PORT_SESS_ATT = "errorMess";
}

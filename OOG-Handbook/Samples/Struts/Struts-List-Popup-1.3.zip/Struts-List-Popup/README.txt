Sample code of Struts to demo:

*** Version 1.3
- Rename projec form Struts-List into Strut-List-Popup
- Add pop-up to select certificate
*** Version 1.2
- Add combo-box

*** Version 1.1
- Input data as a table.

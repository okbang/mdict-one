/**
 * Licensed to Open-Ones Group under one or more contributor license
 * agreements. See the NOTICE file distributed with this work
 * for additional information regarding copyright ownership.
 * Open-Ones Group licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a
 * copy of the License at:
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package openones.tms.strutslist.action;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import openones.tms.strutslist.bean.UserListForm;
import openones.tms.strutslist.bean.session.SessionUserInfo;
import openones.tms.strutslist.bl.UserListBL;

import org.apache.log4j.Logger;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;


public class UserListAction extends Action {
    /** Using Log4j for logging. */
    private final static Logger LOG = Logger.getLogger(UserListAction.class);
    
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form,
            HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        String forwardName = "init";
        String cmd = request.getParameter("Submit");
        UserListForm userListForm = (UserListForm) form;
        UserListBL userListBL = new UserListBL();
        LOG.debug("cmd='" + cmd + "'");
        
        if (cmd == null) { // Initial
            LOG.debug("Initial");
            userListForm.setUserList(userListBL.getAllUsers());
            userListForm.setCountryList(userListBL.getAllCountries());
        } else if ("Update".equals(cmd)) { 
            LOG.debug("Update...");
            LOG.debug("User List; size=" + userListForm.getUserList().size());
            LOG.debug("Update...");
            LOG.debug("FirstName at row 0..." + userListForm.getUserList().get(0).getFirstName());
             
        } else if ("Delete".equals(cmd)) { 
            LOG.debug("Delete...");
            
            // Contained indexes of deleted items
            List<String> deletedCodes = new ArrayList<String>();
            List<SessionUserInfo> userList = userListForm.getUserList();
            
            for (int i = 0; i < userList.size(); i++) {
                if (userList.get(i).isChecked()) { // Delete
                    deletedCodes.add(userList.get(i).getCode());
                    LOG.debug("Delete item " + i + ";code=" + userList.get(i).getCode());
                }
            }
            userListBL.delete(deletedCodes);
            LOG.debug("After deleted; User List; size=" + userListForm.getUserList().size());
            userListForm.setUserList(userListBL.getAllUsers());
        }
        
        return mapping.findForward(forwardName);
    }
}

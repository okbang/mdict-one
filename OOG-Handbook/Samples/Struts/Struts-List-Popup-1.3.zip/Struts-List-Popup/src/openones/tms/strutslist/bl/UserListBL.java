/**
 * Licensed to Open-Ones Group under one or more contributor license
 * agreements. See the NOTICE file distributed with this work
 * for additional information regarding copyright ownership.
 * Open-Ones Group licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a
 * copy of the License at:
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package openones.tms.strutslist.bl;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import openones.tms.strutslist.bean.session.SessionUserInfo;
import openones.tms.strutslist.dao.UserDao;
import openones.tms.strutslist.entity.UserEntity;


public class UserListBL {
    /** Displayed date format */
    private final static String DIS_DATE_FORMAT = "dd-MM-yyyy";
    
    public List<SessionUserInfo> getAllUsers() {
        List<SessionUserInfo> sUserInfoList = new ArrayList<SessionUserInfo>();

        // Get the list of user from the database
        UserDao userDao = new UserDao();
        List<UserEntity> userEntityList = userDao.getAllUsers();
        
        // Convert UserEntity into SessionUserInfo
        for (UserEntity userEnt: userEntityList) {
            sUserInfoList.add(convert(userEnt));
        }

        return sUserInfoList;
    }
    
    final SessionUserInfo convert(UserEntity userEnt) {
        SessionUserInfo sUserInfo = new SessionUserInfo();
        sUserInfo.setCode(userEnt.getCode());
        sUserInfo.setFirstName(userEnt.getFirstName());
        sUserInfo.setLastName(userEnt.getLastName());
        sUserInfo.setBirthday(convert(userEnt.getBirthday(), DIS_DATE_FORMAT));
        sUserInfo.setPhone(userEnt.getPhone());
        sUserInfo.setCountry(userEnt.getCountry());
        
        return sUserInfo;
    }
    
    final String convert(Date dte, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        return sdf.format(dte);
    }

    public void delete(List<String> deletedCodes) {
        UserDao userDao = new UserDao();
        userDao.delete(deletedCodes);
        
    }

	public List<String> getAllCountries() {
		//String[] COUNTRIES = new String[] {"VN", "JP", "US"};
		List<String> countryList = new ArrayList<String>();
		countryList.add("VN");
		countryList.add("JP");
		countryList.add("US");
		
		return countryList;
	}
}

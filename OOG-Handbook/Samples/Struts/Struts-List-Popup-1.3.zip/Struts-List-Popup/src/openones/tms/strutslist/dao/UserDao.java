/**
 * Licensed to Open-Ones Group under one or more contributor license
 * agreements. See the NOTICE file distributed with this work
 * for additional information regarding copyright ownership.
 * Open-Ones Group licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a
 * copy of the License at:
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package openones.tms.strutslist.dao;

import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;

import openones.tms.strutslist.entity.UserEntity;

public class UserDao {
    static List<UserEntity> sampleUserList = null;

    public List<UserEntity> getAllUsers() {
        return getSampleUsers();
    }

    public void delete(List<String> userCodes) {
        UserEntity userEnt;
        int i = 0;

        while (i < sampleUserList.size()) {
            userEnt = sampleUserList.get(i);
            if (userCodes.contains(userEnt.getCode())) {
                sampleUserList.remove(userEnt);
            } else {
                i++;
            }
        }
    }

    private static Date parseDate(String dateStr, String format) {
        SimpleDateFormat sdf = new SimpleDateFormat(format);
        Date dateObj = null;
        try {
            dateObj = (Date) sdf.parse(dateStr);
        } catch (ParseException pex) {
            pex.printStackTrace();
        }
        return dateObj;
    }

    final static List<UserEntity> getSampleUsers() {
        if (sampleUserList == null) {
            sampleUserList = new ArrayList<UserEntity>();
            UserEntity userEnt;
            Date birthDay;
            for (int i = 0; i < 10; i++) {
                birthDay = parseDate((i + 1) + "/08/2008", "dd/MM/yyy");
                userEnt = new UserEntity("Code" + i, "Đường" + i, "Lê Hải", birthDay, "08 01279" + i, "US");
                sampleUserList.add(userEnt);
            }
        }
        return sampleUserList;
    }
}

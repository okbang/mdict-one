/**
 * Licensed to Open-Ones Group under one or more contributor license
 * agreements. See the NOTICE file distributed with this work
 * for additional information regarding copyright ownership.
 * Open-Ones Group licenses this file to you under the Apache License,
 * Version 2.0 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a
 * copy of the License at:
 *
 * http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing,
 * software distributed under the License is distributed on
 * an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY
 * KIND, either express or implied. See the License for the
 * specific language governing permissions and limitations
 * under the License.
 */
package openones.tms.strutslist.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import openones.tms.strutslist.bean.CertListForm;
import openones.tms.strutslist.bl.CertBL;

import org.apache.log4j.Logger;
import org.apache.struts.action.Action;
import org.apache.struts.action.ActionForm;
import org.apache.struts.action.ActionForward;
import org.apache.struts.action.ActionMapping;

/**
 * @author likejforum
 *
 */
public class CertListAction extends Action {
    /** Using Log4j for logging. */
    private final static Logger LOG = Logger.getLogger(CertListAction.class);
    
    /**
     * [Explain the description for this method here].
     * @param mapping
     * @param form
     * @param request
     * @param response
     * @return
     * @throws Exception
     * @see org.apache.struts.action.Action#execute(org.apache.struts.action.ActionMapping, org.apache.struts.action.ActionForm, javax.servlet.http.HttpServletRequest, javax.servlet.http.HttpServletResponse)
     */
    @Override
    public ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request,
            HttpServletResponse response) throws Exception {
        String forwardName = "init";
        String cmd = request.getParameter("Submit");
        CertListForm certListForm = (CertListForm) form;
        
        if (cmd == null) { // Initial
            LOG.debug("Initial");
            certListForm.setCertList(CertBL.getCerts());
        } else if ("Update".equals(cmd)) { 
            
        }
        return mapping.findForward(forwardName);
    }

}
